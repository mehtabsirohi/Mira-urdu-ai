# Mira Urdu AI — Android project source

This is the Android Studio project wrapper for the included Mira web app.

## Build an APK at no cost
1. Install Android Studio (free) on a computer: https://developer.android.com/studio
2. Extract this ZIP and open the `mira-urdu-android` folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location (normally `app/build/outputs/apk/debug/app-debug.apk`).

## Important feature limitations
- The included UI/web app is a starter. The included default behavior is demo mode until a user connects an AI API key in Settings.
- Speech recognition depends on Android WebView/device support and may require Google speech services and internet. Urdu (Pakistan) support varies by device.
- This is not a full Maya clone and is not affiliated with Maya. It does not include an unlimited AI model, a human-like avatar, or guaranteed always-on background listening.
- No paid services are required to compile the project. AI provider quotas, terms, and availability may change.
